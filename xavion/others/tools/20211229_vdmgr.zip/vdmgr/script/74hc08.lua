
-- pin3  = pin1  and pin2
-- pin6  = pin4  and pin5
-- pin8  = pin9  and pin10
-- pin11 = pin12 and pin13


function updatePin()
	vdmod_writePin(3,  vdmod_readPin(1)  & vdmod_readPin(2))
	vdmod_writePin(6,  vdmod_readPin(4)  & vdmod_readPin(5))
	vdmod_writePin(8,  vdmod_readPin(9)  & vdmod_readPin(10))
	vdmod_writePin(11, vdmod_readPin(12) & vdmod_readPin(13))
end


function onReset(hard)
	updatePin()
end


function onStop(hard)
	updatePin()
end


function onWritePin(pin, value)
	vdmod_attachClockEvent(0, 1)
end


function onEventProcess(index)
	updatePin()
end
